package com.example.aws.springboot.master;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwsSpringbootMasterApplicationTests {

	@Test
	void contextLoads() {
	}

}
