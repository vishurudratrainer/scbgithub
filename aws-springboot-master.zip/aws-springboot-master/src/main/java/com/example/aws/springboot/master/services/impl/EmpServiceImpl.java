package com.example.aws.springboot.master.services.impl;

import com.example.aws.springboot.master.models.Emp;
import com.example.aws.springboot.master.services.EmpService;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

@Service
public class EmpServiceImpl implements EmpService {

    Map<Integer,Emp> empMap = new HashMap<>();
    @Override
    public Collection<Emp> getAll() {
        return empMap.values();
    }

    @Override
    public boolean add(Emp emp) {
        empMap.put(emp.getId(),emp);
        return true;
    }
}
