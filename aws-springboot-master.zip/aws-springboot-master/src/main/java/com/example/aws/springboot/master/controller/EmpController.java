package com.example.aws.springboot.master.controller;

import com.example.aws.springboot.master.models.Emp;
import com.example.aws.springboot.master.services.EmpService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;

@RestController
public class EmpController {

    private final EmpService empService;

    public EmpController(EmpService empService) {
        this.empService = empService;
    }

    @GetMapping("/emp")
    public Collection<Emp> getAll(){
        return  empService.getAll();
    }

    @PostMapping("/emp")
    public  boolean add(@RequestBody Emp emp){
        return empService.add(emp);
    }
}
