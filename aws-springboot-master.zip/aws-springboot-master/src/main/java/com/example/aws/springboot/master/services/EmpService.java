package com.example.aws.springboot.master.services;

import com.example.aws.springboot.master.models.Emp;

import java.util.Collection;

public interface EmpService {

    Collection<Emp> getAll();
    boolean add(Emp emp);

}
