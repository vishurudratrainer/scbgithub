package com.example.aws.springboot.master.models;

public class Emp {
    public Emp(){

    }
    public Emp(Integer id, String empName, Double salary) {
        this.id = id;
        this.empName = empName;
        this.salary = salary;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    private Integer id;
    private String empName;
    private Double salary;
}
