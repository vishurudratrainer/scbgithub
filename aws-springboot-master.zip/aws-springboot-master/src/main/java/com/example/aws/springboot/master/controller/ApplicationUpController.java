package com.example.aws.springboot.master.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ApplicationUpController {

    @GetMapping("/")
    public String appUp(){
        return "Master Class Application is up and running";
    }
}
